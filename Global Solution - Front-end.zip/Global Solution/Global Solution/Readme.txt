Usuário GitHub  
Email: Kaiangustavo20@gmail.com  
Senha: Kaian100#  
 
Link Repositório 
https://github.com/kaianGU/Global-Solution-SmartEnergy


Figma  
https://www.figma.com/design/gOz6xz20Ryqslm9NJzAaEY/SmartEnergy?t=Ir2srPIBqRWb7lUw-1


vídeo apresentação
https://youtu.be/K8_62xGQSNU