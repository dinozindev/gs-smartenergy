package br.com.fiap.conexao;

public class Credenciais {
    public static final String user = "rm554424";
    public static final String pwd = "040704";

}
